var searchData=
[
  ['aligned_20allocation',['Aligned Allocation',['../group__aligned.html',1,'']]]
];

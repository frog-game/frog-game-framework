var searchData=
[
  ['heap_20introspection',['Heap Introspection',['../group__analysis.html',1,'']]],
  ['heap_20allocation',['Heap Allocation',['../group__heap.html',1,'']]]
];

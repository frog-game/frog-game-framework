#include "redis_parser.h"

#include <string.h>
#include <stdlib.h>
#include <assert.h>

#if defined(__GNUC__)
#	define _Likely(x)   	(__builtin_expect((x), 1))
#	define _UnLikely(x) 	(__builtin_expect((x), 0))
#else
#	define _Likely(x)  	    (x)
#	define _UnLikely(x) 	(x)
#endif

#define REDIS_BULK_STR_LENGTH	    10 
#define REDIS_INTEGER_STR_LENGTH	20 

void redis_parser_reset(redis_parser_tt* p)
{
	p->index = -1;
    p->iBulkLength = 0;
    p->state = redis_parser_state_end;
	p->type = redis_parser_type_unknown;
	p->parserErrno = redis_errno_ok;
}

void redis_parser_init(redis_parser_tt* p,void* userData)
{
    p->userData = userData;
    redis_parser_reset(p);
}


size_t redis_parser_execute(redis_parser_tt *p, const redis_parser_settings_tt* settings, const char* buf, size_t len)
{
    if (_UnLikely(len == 0))
    {
        return 0;
    }

	char bulkLength[REDIS_BULK_STR_LENGTH + 1];
	char number[REDIS_INTEGER_STR_LENGTH+ 1];

    const char* end =  buf + len;
    const char* begin = buf;

reexecute:
    for (; _Likely(begin < end); begin++)
    {
        switch (p->state)
        {
        case redis_parser_state_end:
        case redis_parser_state_array:
            {
                switch (*begin)
                {
                case '+':
                    {
                        ++p->index;
                        if(_UnLikely(p->index>=REDIS_ARRAY_LEVEL))
                        {
                            p->parserErrno = redis_errno_parser_level;
                            return 0;
                        }
                        p->countStack[p->index] = 1;
                        p->type = redis_parser_type_line;
                        p->state = redis_parser_state_line;
                    }
                    break;
                case '-':
                    {
                        ++p->index;
                        if(_UnLikely(p->index>=REDIS_ARRAY_LEVEL))
                        {
                            p->parserErrno = redis_errno_parser_level;
                            return 0;
                        }
                        p->countStack[p->index] = 1;
                        p->type = redis_parser_type_error;
                        p->state = redis_parser_state_error;
                    }
                    break;
                case ':':
                    {
                        ++p->index;
                        if(_UnLikely(p->index>=REDIS_ARRAY_LEVEL))
                        {
                            p->parserErrno = redis_errno_parser_level;
                            return 0;
                        }
                        p->countStack[p->index] = 1;
                        p->type = redis_parser_type_integer;
                        p->state = redis_parser_state_integer;
                    }
                    break;
                case '$':
                    {
                        ++p->index;
                        if(_UnLikely(p->index>=REDIS_ARRAY_LEVEL))
                        {
                            p->parserErrno = redis_errno_parser_level;
                            return 0;
                        }
                        p->countStack[p->index] = 1;
                        p->type = redis_parser_type_bulk;
                        p->state = redis_parser_state_bulkLength;
                    }
                    break;
                case '*':
                    {
                        ++p->index;
                        if(_UnLikely(p->index>=REDIS_ARRAY_LEVEL))
                        {
                            p->parserErrno = redis_errno_parser_level;
                            return 0;
                        }
                        p->countStack[p->index] = -1;
                        p->type = redis_parser_type_array;
                        p->state = redis_parser_state_arrayCount;
                    }
                    break;
                }
            }
            break;
        case redis_parser_state_line:
            {
                const char* data = begin;
                const char* findCRLF = begin + 1;
                while (_Likely(findCRLF < end))
                {
                    const char* LF = findCRLF;
                    if(_UnLikely(*LF == '\n'))
                    {
                        const char* CR = findCRLF-1;
                        if(_Likely(*CR == '\r'))
                        {
                            assert(settings->on_line);
                            if(_UnLikely(settings->on_line(p,data,CR-data) == -1))
                            {
                                p->parserErrno = redis_errno_parser_line;
                                return 0;  
                            }

                            do
                            {
                                --(p->countStack[p->index]);
                                if(p->countStack[p->index] == 0)
                                {
                                    --p->index;
                                }
                                else
                                {
                                    break;
                                }
                            } while (p->index >= 0);
                            
                            if(p->index < 0)
                            {
                                p->state = redis_parser_state_end;
                                assert(settings->on_complete);
                                if(_UnLikely(settings->on_complete(p) == -1))
                                {
                                    p->parserErrno = redis_errno_parser_line;
                                    return 0; 
                                }
                            }
                            else
                            {
                                p->state = redis_parser_state_array;
                            }
                            begin = findCRLF+1;
                            goto reexecute;
                        }
                    }
                    findCRLF++;
                }
            }
            break;
        case redis_parser_state_error:
            {
                const char* data = begin;
                const char* findCRLF = begin + 1;
                while (_Likely(findCRLF < end))
                {
                    const char* LF = findCRLF;
                    if(_UnLikely(*LF == '\n'))
                    {
                        const char* CR = findCRLF-1;
                        if(_Likely(*CR == '\r'))
                        {
                            assert(settings->on_error);
                            if(_UnLikely(settings->on_error(p,data,CR-data) == -1))
                            {
                                p->parserErrno = redis_errno_parser_error;
                                return 0;
                            }
                            do
                            {
                                --(p->countStack[p->index]);
                                if(p->countStack[p->index] == 0)
                                {
                                    --p->index;
                                }
                                else
                                {
                                    break;
                                }
                            } while (p->index >= 0);
                            
                            if(p->index < 0)
                            {
                                p->state = redis_parser_state_end;
                                assert(settings->on_complete);
                                if(_UnLikely(settings->on_complete(p) == -1))
                                {
                                    p->parserErrno = redis_errno_parser_error;
                                    return 0; 
                                }
                            }
                            else
                            {
                                p->state = redis_parser_state_array;
                            }
                            begin = findCRLF + 1;
                            goto reexecute;
                        }
                    }
                    findCRLF++;
                }
            }
            break;
        case redis_parser_state_integer:
            {
                const char* data = begin;
                const char* findCRLF = begin + 1;
                while (_Likely(findCRLF < end))
                {
                    const char* LF = findCRLF;
                    if(_UnLikely(*LF == '\n'))
                    {
                        const char* CR = findCRLF-1;
                        if(_Likely(*CR == '\r'))
                        {
                            assert(settings->on_integer);
                            memcpy(number, data, CR-data);
                            number[CR-data] = '\0';
                            if(_UnLikely(settings->on_integer(p,strtoull(number, NULL, 10)) == -1))
                            {
                                p->parserErrno = redis_errno_parser_integer;
                                return 0;
                            }

                            do
                            {
                                --(p->countStack[p->index]);
                                if(p->countStack[p->index] == 0)
                                {
                                    --p->index;
                                }
                                else
                                {
                                    break;
                                }
                            } while (p->index >= 0);
                            
                            if(p->index < 0)
                            {
                                p->state = redis_parser_state_end;
                                assert(settings->on_complete);
                                if(_UnLikely(settings->on_complete(p) == -1))
                                {
                                    p->parserErrno = redis_errno_parser_integer;
                                    return 0; 
                                }
                            }
                            else
                            {
                                p->state = redis_parser_state_array;
                            }
                            begin = findCRLF + 1;
                            goto reexecute;
                        }
                    }
                    findCRLF++;
                }
            }
            break;
        case redis_parser_state_bulkLength:
            {
                const char* data = begin;
                const char* findCRLF = begin + 1;
                while (_Likely(findCRLF < end))
                {
                    const char* LF = findCRLF;
                    if(_UnLikely(*LF == '\n'))
                    {
                        const char* CR = findCRLF-1;
                        if(_Likely(*CR == '\r'))
                        {
                            memcpy(bulkLength, data, CR-data);
							bulkLength[CR-data] = '\0';
                            p->iBulkLength = atoi(bulkLength);

                            assert(settings->on_bulk_length);
                            if(settings->on_bulk_length(p,p->iBulkLength) == -1)
                            {
                                p->parserErrno = redis_errno_parser_bulk;
                                return 0; 
                            }
                            if(p->iBulkLength == -1)
                            {
                                do
                                {
                                    --(p->countStack[p->index]);
                                    if(p->countStack[p->index] == 0)
                                    {
                                        --p->index;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                } while (p->index >= 0);

                                if(p->index < 0)
                                {
                                    p->state = redis_parser_state_end;
                                    assert(settings->on_complete);
                                    if(_UnLikely(settings->on_complete(p) == -1))
                                    {
                                        p->parserErrno = redis_errno_parser_bulk;
                                        return 0; 
                                    }
                                }
                                else
                                {
                                    p->state = redis_parser_state_array;
                                }
                            }
                            else
                            {
                                p->state = redis_parser_state_bulkData;
                            }
                            begin = findCRLF + 1;
                            goto reexecute;
                        }
                    }
                    findCRLF++;
                }
            }
            break;
        case redis_parser_state_bulkData:
            {
                size_t length = end - begin;
                if(p->iBulkLength >= length)
                {
                    assert(settings->on_bulk);
                    if(_UnLikely(settings->on_bulk(p,begin,length) == -1))
                    {
                        p->parserErrno = redis_errno_parser_bulk;
                        return 0; 
                    }
                    p->iBulkLength -=length;
                    return len;
                }
                else if(p->iBulkLength+2 <= length)
                {
                    if(p->iBulkLength > 0)
                    {
                        assert(settings->on_bulk);
                        if(_UnLikely(settings->on_bulk(p,begin,p->iBulkLength) == -1))
                        {
                            p->state = redis_errno_parser_bulk;
                            return 0;
                        }
                        begin = begin+p->iBulkLength;
                        p->iBulkLength = 0;
                    }
                    begin += 2;
                    do
                    {
                        --(p->countStack[p->index]);
                        if(p->countStack[p->index] == 0)
                        {
                            --p->index;
                        }
                        else
                        {
                            break;
                        }
                    } while (p->index >= 0);
                    
                    if(p->index < 0)
                    {
                        p->state = redis_parser_state_end;
                        assert(settings->on_complete);
                        if(_UnLikely(settings->on_complete(p) == -1))
                        {
                            p->parserErrno = redis_errno_parser_bulk;
                            return 0; 
                        }
                    }
                    else
                    {
                        p->state = redis_parser_state_array;
                    }
                    goto reexecute;
                }
            }
            break;
        case redis_parser_state_arrayCount:
            {
                const char* data = begin;
                const char* findCRLF = begin + 1;
                while (_Likely(findCRLF < end))
                {
                    const char* LF = findCRLF;
                    if(_UnLikely(*LF == '\n'))
                    {
                        const char* CR = findCRLF-1;
                        if(_Likely(*CR == '\r'))
                        {
                            memcpy(number, data, CR-data);
                            number[CR-data] = '\0';

                            p->countStack[p->index] = strtoull(number, NULL, 10);

                            assert(settings->on_array_count);
                            if(_UnLikely(settings->on_array_count(p,p->countStack[p->index]) == -1))
                            {
                                p->parserErrno = redis_errno_parser_array;
                                return 0; 
                            }

                            if(p->countStack[p->index] == 0/* || p->countStack[p->index] == -1*/)
                            {
                                --p->index;
                                while (p->index >= 0)
                                {
                                     --(p->countStack[p->index]);
                                    if(p->countStack[p->index] == 0)
                                    {
                                        --p->index;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if(p->index < 0)
                                {
                                    p->state = redis_parser_state_end;
                                    assert(settings->on_array_count);
                                    if(_UnLikely(settings->on_complete(p) == -1))
                                    {
                                        p->parserErrno = redis_errno_parser_array;
                                        return 0; 
                                    }
                                }
                                else
                                {
                                    p->state = redis_parser_state_array;
                                }
                            }
                            else
                            {
                                p->state = redis_parser_state_array;
                            }
                            begin = findCRLF+1;
                            goto reexecute;
                        }
                    }
                    findCRLF++;
                }
            }
            break;
        }
    }
    return len - (end - begin);
}

void redis_parser_set_data(redis_parser_tt* p, void* userData)
{
    p->userData = userData;
}

void* redis_parser_get_data(redis_parser_tt* p)
{
    return p->userData;
}

#ifndef def_redis_parser_h
#define def_redis_parser_h

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

enum
{
	redis_errno_ok,
    redis_errno_parser_line,
    redis_errno_parser_error,
    redis_errno_parser_integer,
    redis_errno_parser_bulk,
    redis_errno_parser_array,
    redis_errno_parser_level,
};

enum
{
	redis_parser_type_unknown,
    redis_parser_type_line,
    redis_parser_type_error,
    redis_parser_type_integer,
    redis_parser_type_bulk,
    redis_parser_type_array,
};

enum
{
	redis_parser_state_end,
    redis_parser_state_line,
    redis_parser_state_error,
    redis_parser_state_integer,
    redis_parser_state_bulkLength,
    redis_parser_state_bulkData,
	redis_parser_state_arrayCount,
    redis_parser_state_array
};

#define REDIS_ARRAY_LEVEL       64

#define REDIS_PARSER_STATE(p)   ((p)->state)
#define REDIS_PARSER_ERRNO(p)   ((p)->parserErrno)

typedef struct redis_parser_s redis_parser_tt;

typedef int32_t (*redis_cb) (redis_parser_tt*);

typedef int32_t (*redis_data_cb) (redis_parser_tt*,const char* /*data*/,int32_t /*length*/);

typedef int32_t (*redis_data_length_cb) (redis_parser_tt*,int32_t/*length*/);

typedef int32_t (*redis_data_integer_cb) (redis_parser_tt*,int64_t/*data*/);

typedef struct redis_parser_settings_s
{
	redis_cb      			    on_complete;
    redis_data_cb               on_line;
    redis_data_cb               on_error;
    redis_data_integer_cb       on_integer;
    redis_data_length_cb        on_bulk_length;
    redis_data_cb               on_bulk;
    redis_data_integer_cb       on_array_count;
} redis_parser_settings_tt;

struct redis_parser_s
{
	void* 		userData;
	int32_t 	index;
    int64_t     countStack[REDIS_ARRAY_LEVEL];
    int32_t     iBulkLength;
	uint8_t		type;
	uint8_t		state;
    uint8_t     parserErrno;
};

void redis_parser_init(redis_parser_tt* p,void* userData);

void redis_parser_reset(redis_parser_tt* p);

size_t redis_parser_execute(redis_parser_tt *p, const redis_parser_settings_tt* settings, const char* buf, size_t len);

void redis_parser_set_data(redis_parser_tt* p, void* userData);

void* redis_parser_get_data(redis_parser_tt* p);

#endif
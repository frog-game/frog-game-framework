#include "mysql_parser.h"

#include <string.h>
#include <stdlib.h>
#include <assert.h>

#if defined(__clang__)
#define def_VariableLengthArrays 
#elif defined(__GNUC__) || defined(__GNUG__)
#define def_VariableLengthArrays
#endif

#define CLIENT_PROTOCOL_41 512

#define SERVER_MORE_RESULTS_EXISTS 8

static inline uint16_t byte2ToUinteger(const char* s)
{
	return (uint16_t)((uint8_t)(s[0])) | (uint16_t)((uint8_t)(s[1])) << 8;
}

static inline uint32_t byte3ToUinteger(const char* s)
{
	return (uint32_t)((uint8_t)(s[0])) | (uint32_t)((uint8_t)(s[1])) << 8 | (uint32_t)((uint8_t)(s[2])) << 16;
}

static inline uint32_t byte4ToUinteger(const char* s)
{
	return (uint32_t)((uint8_t)(s[0])) | (uint32_t)((uint8_t)(s[1])) << 8 | (uint32_t)((uint8_t)(s[2])) << 16 | (uint32_t)((uint8_t)(s[3])) << 24;
}

static inline uint64_t byte8ToUinteger(const char* s)
{
	return (uint64_t)((uint8_t)(s[0]))  | (uint64_t)((uint8_t)(s[1]))  << 8 | (uint64_t)((uint8_t)(s[2])) << 16 | (uint64_t)((uint8_t)(s[3])) << 24 | (uint64_t)((uint8_t)(s[4])) << 32 | (uint64_t)((uint8_t)(s[5])) << 40 | (uint64_t)((uint8_t)(s[6])) << 48 | (uint64_t)((uint8_t)(s[7])) << 56;
}

static inline int32_t decodeFromLength(const char* begin, const char* end, uint64_t* pLength)
{
	switch (*(const uint8_t*)begin)
	{
	case 251:
		{
			*pLength = 0;
			return 1;
		}
		break;
	case 252:
		{
			if (begin + 2 > end)
			{
				return -1;
			}
			*pLength = byte2ToUinteger(begin + 1);
			return 3;
		}
		break;
	case 253:
		{
			if (begin + 3 > end)
			{
				return -1;
			}
			*pLength = byte3ToUinteger(begin + 1);
			return 4;
		}
		break;
	case 254:
		{
			if (begin + 8 > end)
			{
				return -1;
			}
			*pLength = byte8ToUinteger(begin + 1);
			return 9;
		}
		break;
	case 255:
		{
			return 0;
		}
		break;
	default:
		{
			*pLength = *(const uint8_t*)begin;
			return 1;
		}
	}
	return 0;
}


static inline size_t parse_packet_error(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	p->state = mysql_parser_state_error;
	const char* end = buf + len;
	size_t nOffset = 0;
	if (buf + 9 > end)
		return 0;
	++nOffset;
	uint16_t mysql_errno = byte2ToUinteger(buf + nOffset);
	nOffset += 2;

	size_t nSqlStateOffset = 0;
	size_t nErrorMsgOffset = 0;
	size_t nErrorMsgLength = 0;

	if (*(buf + nOffset) == '#')
	{
		++nOffset;
		nSqlStateOffset = nOffset;
		nOffset += MYSQL_STATE_LENGTH;
		nErrorMsgOffset = nOffset;
		nErrorMsgLength = len - nErrorMsgOffset;
		nOffset += nErrorMsgLength;
	}
	assert(settings->on_error);
	if (settings->on_error(p, mysql_errno, nErrorMsgLength, buf + nErrorMsgOffset, buf + nSqlStateOffset) == -1)
	{
		p->parserErrno = mysql_errno_parser_error;
		return 0;
	}

	assert(settings->on_complete);
	if (settings->on_complete(p) == -1)
	{
		p->parserErrno = mysql_errno_parser_error;
		return 0;
	}

	p->state = mysql_parser_state_end;
	return nOffset;
}

static inline size_t parse_packet_handshake(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	p->state = mysql_parser_state_handshake;
	const char* end = buf + len;
	const char* pos;

	uint8_t uiProtocolVersion = *buf;
	if (uiProtocolVersion == mysql_header_error)
	{
		return parse_packet_error(p, settings, buf, len);
	}

	pos = ++buf;
	const char* szServerVersion = pos;

	while (pos < end && *pos)
		pos++;

	if (pos >= end || end - pos < 43)
		return 0;

	buf = pos + 1;

	uint32_t uiThreadId = byte4ToUinteger(buf);
	buf += 4;
	char szScramble[21];
	memcpy(szScramble, buf, 8);
	buf += 9;
	uint32_t uiServerCapabilities = byte2ToUinteger(buf);
	buf += 2;

	uint8_t uiServerLang = *buf++;
	uint16_t uiServerStatus = byte2ToUinteger(buf);
	buf += 2;

	uiServerCapabilities |= ((uint32_t)byte2ToUinteger(buf) << 16);
	buf += 2;
	buf += 11;
	memcpy(szScramble + 8, buf, 12);
	szScramble[20] = '\0';
	assert(settings->on_handshake);
	if (settings->on_handshake(p, uiProtocolVersion, szServerVersion, uiThreadId, szScramble, uiServerCapabilities, uiServerLang, uiServerStatus) == -1)
	{
		p->parserErrno = mysql_errno_parser_handshake;
		return 0;
	}

	assert(settings->on_complete);
	if (settings->on_complete(p) == -1)
	{
		p->parserErrno = mysql_errno_parser_handshake;
		return 0;
	}
	p->state = mysql_parser_state_end;
	return len;
}

static inline size_t parse_packet_ok(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	p->state = mysql_parser_state_ok;
	const char* end = buf + len;
	size_t nOffset = 0;
	uint64_t uiAffectedRows = 0;
	uint64_t uiInsertId = 0;
	uint16_t uiServerStatus = 0;
	uint16_t uiWarningCount = 0;

	nOffset += 1;

	int32_t iOffset = decodeFromLength(buf + nOffset, end, &uiAffectedRows);
	if (iOffset == -1)
	{
		return 0;
	}

	nOffset += iOffset;

	iOffset = decodeFromLength(buf + nOffset, end, &uiInsertId);
	if (iOffset == -1)
	{
		return 0;
	}

	nOffset += iOffset;

	if (buf + nOffset + 4 > end)
	{
		return 0;
	}

	uiServerStatus = byte2ToUinteger(buf + nOffset);
	nOffset += 2;
	uiWarningCount = byte2ToUinteger(buf + nOffset);
	nOffset += 2;


	uint64_t uiMessageLength = 0;
	size_t nMessageOffset = 0;

	if (buf + nOffset < end)
	{
		iOffset = decodeFromLength(buf + nOffset, end, &uiMessageLength);
		if (iOffset == -1)
		{
			return 0;
		}

		nOffset += iOffset;

		if (buf + nOffset + uiMessageLength > end)
		{
			return 0;
		}

		nMessageOffset = nOffset;
		nOffset += (size_t)uiMessageLength;
	}

	assert(settings->on_ok);
	if (settings->on_ok(p, uiAffectedRows, uiInsertId, uiServerStatus, uiWarningCount, buf + nMessageOffset, (size_t)uiMessageLength) == -1)
	{
		p->parserErrno = mysql_errno_parser_ok;
		return 0;
	}

	if (!(uiServerStatus & SERVER_MORE_RESULTS_EXISTS))
	{
		assert(settings->on_complete);
		if (settings->on_complete(p) == -1)
		{
			p->parserErrno = mysql_errno_parser_ok;
			return 0;
		}
	}
	p->state = mysql_parser_state_end;
	return nOffset;
}


static inline size_t parse_packet_eof(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	const char* end = buf + len;
	if (buf + 5 > end)
		return 0;

	if (p->state == mysql_parser_state_columnDef)
	{
		p->state = mysql_parser_state_row;
	}
	else
	{

		uint16_t flag = byte2ToUinteger(buf + 3);
		if (!(flag & SERVER_MORE_RESULTS_EXISTS))
		{
			assert(settings->on_complete);
			if (settings->on_complete(p) == -1)
			{
				p->parserErrno = mysql_errno_parser_eof;
				return 0;
			}
			p->state = mysql_parser_state_end;
		}
		else
		{
			p->state = mysql_parser_state_resultSet;
		}
	}
	return 5;
}

static inline size_t parse_packet_field_count(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	const char* end = buf + len;

	size_t nOffset = 0;
	uint64_t uiFieldCount = 0;

	int32_t iOffset = decodeFromLength(buf + nOffset, end, &uiFieldCount);
	if (iOffset == -1)
	{
		return 0;
	}
	p->fieldCount = (uint32_t)uiFieldCount;
	p->fieldIndex = 0;
	nOffset += iOffset;
	if (uiFieldCount > 0)
	{
		assert(settings->on_field_count);
		if (settings->on_field_count(p, p->fieldCount) == -1)
		{
			p->parserErrno = mysql_errno_parser_field_count;
			return 0;
		}
	}
	p->state = mysql_parser_state_columnDef;

	return nOffset;
}

static inline size_t parse_packet_column_def(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	const char* end = buf + len;

	size_t nOffset = 0;

	size_t nCatalogOffset = 0;
	uint64_t uiCatalogLength = 0;

	size_t nDBOffset = 0;
	uint64_t uiDBLength = 0;

	size_t nTableOffset = 0;
	uint64_t uiTableLength = 0;

	size_t nOrgTableOffset = 0;
	uint64_t uiOrgTableLength = 0;

	size_t nNameOffset = 0;
	uint64_t uiNameLength = 0;

	size_t nOrgNameOffset = 0;
	uint64_t uiOrgNameLength = 0;

	int32_t iOffset = decodeFromLength(buf + nOffset, end, &uiCatalogLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nCatalogOffset = nOffset;
	nOffset += (size_t)uiCatalogLength;

	iOffset = decodeFromLength(buf + nOffset, end, &uiDBLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nDBOffset = nOffset;
	nOffset += (size_t)uiDBLength;

	iOffset = decodeFromLength(buf + nOffset, end, &uiTableLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nTableOffset = nOffset;
	nOffset += (size_t)uiTableLength;

	iOffset = decodeFromLength(buf + nOffset, end, &uiOrgTableLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nOrgTableOffset = nOffset;
	nOffset += (size_t)uiOrgTableLength;


	iOffset = decodeFromLength(buf + nOffset, end, &uiNameLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nNameOffset = nOffset;
	nOffset += (size_t)uiNameLength;

	iOffset = decodeFromLength(buf + nOffset, end, &uiOrgNameLength);
	if (iOffset == -1)
	{
		return 0;
	}
	nOffset += iOffset;
	nOrgNameOffset = nOffset;
	nOffset += (size_t)uiOrgNameLength;


	if (buf + nOffset + 13 > end)
	{
		return 0;
	}

	++nOffset;

	uint16_t uiCharsetnr = byte2ToUinteger(buf + nOffset);
	nOffset += 2;
	uint32_t uiLength = byte4ToUinteger(buf + nOffset);
	nOffset += 4;

	uint8_t uiType = *(buf + nOffset);
	++nOffset;
	uint16_t uiFlag = byte2ToUinteger(buf + nOffset);
	nOffset += 2;

	uint8_t uiDecimals = *(buf + nOffset);
	++nOffset;
	nOffset += 2;

	assert(settings->on_column_def);
	if (settings->on_column_def(p, p->fieldIndex, (size_t)uiCatalogLength, buf + nCatalogOffset, (size_t)uiDBLength, buf + nDBOffset, (size_t)uiTableLength, buf + nTableOffset,
		(size_t)uiOrgTableLength, buf + nOrgTableOffset, (size_t)uiNameLength, buf + nNameOffset, (size_t)uiOrgNameLength, buf + nOrgNameOffset, uiLength,
		uiCharsetnr, uiFlag, uiType, uiDecimals) == -1)
	{
		p->parserErrno = mysql_errno_parser_column_def;
		return 0;
	}
	++p->fieldIndex;

	return nOffset;
}

static inline size_t parse_packet_row(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	const char* end = buf + len;

	size_t nOffset = 0;
	const uint32_t field_count = p->fieldCount;
#ifdef def_VariableLengthArrays
	size_t valueLength[field_count];
	size_t valueOffset[field_count];
#else
	char* _variableLengthArrays = (char*)_alloca(sizeof(size_t) * field_count * 2);
	size_t* valueLength = (size_t*)_variableLengthArrays;
	size_t* valueOffset = (size_t*)(_variableLengthArrays + sizeof(size_t) * field_count);
#endif
	int32_t iOffset = 0;
	uint64_t uiLength = 0;
	for (uint32_t i = 0; i < field_count; ++i)
	{
		iOffset = decodeFromLength(buf + nOffset, end, &uiLength);
		if (iOffset == -1)
		{
			return 0;
		}
		nOffset += iOffset;
		valueOffset[i] = nOffset;
		valueLength[i] = (size_t)uiLength;
		nOffset += valueLength[i];
	}

	assert(settings->on_row);
	if (settings->on_row(p, buf, nOffset, valueOffset, valueLength) == -1)
	{
		p->parserErrno = mysql_errno_parser_row;
		return 0;
	}
	return nOffset;
}

void mysql_parser_reset(mysql_parser_tt* p, mysql_parser_type_tt type)
{
	p->type = (uint8_t)type;
	p->state = mysql_parser_state_end;
	p->fieldCount = 0;
	p->fieldIndex = 0;
	p->parserErrno = mysql_errno_ok;
}

void mysql_parser_init(mysql_parser_tt* p, mysql_parser_type_tt type, void* userData)
{
	mysql_parser_reset(p, type);
	p->userData = userData;
}

size_t mysql_parser_execute(mysql_parser_tt* p, const mysql_parser_settings_tt* settings, const char* buf, size_t len)
{
	if (len == 0)
	{
		return 0;
	}
	size_t nRead = 0;
	const char* begin = buf;
	const char* end = buf+len;
	do
	{
		switch (p->type)
		{
		case mysql_parser_type_handshake:
			{
				nRead = parse_packet_handshake(p, settings, begin, end - begin);
			}
			break;
		case mysql_parser_type_result:
			{
				const uint8_t* pType = (const uint8_t*)begin;
				switch (*pType)
				{
				case mysql_header_ok:
					{
						nRead = parse_packet_ok(p, settings, begin, end - begin);
					}
					break;
				case mysql_header_eof:
					{
						nRead = parse_packet_eof(p, settings, begin, end - begin);
					}
					break;
				case mysql_header_error:
					{
						nRead = parse_packet_error(p, settings, begin, end - begin);
					}
					break;
				default:
					{
						switch (p->state)
						{
						case mysql_parser_state_end:
						case mysql_parser_state_resultSet:
							{
								nRead = parse_packet_field_count(p, settings, begin, end - begin);
							}
							break;
						case mysql_parser_state_columnDef:
							{
								nRead = parse_packet_column_def(p, settings, begin, end - begin);
							}
							break;
						case mysql_parser_state_row:
							{
								nRead = parse_packet_row(p, settings, begin, end - begin);
							}
							break;
						}
					}
				}
			}
			break;
		}

		if(nRead == 0)
		{
			break;
		}
		begin += nRead;
	} while (begin < end);

	return begin - buf;
}

mysql_parser_type_tt mysql_parser_get_type(mysql_parser_tt* p)
{
	return (mysql_parser_type_tt)(p->type);
}

void mysql_parser_set_data(mysql_parser_tt* p, void* userData)
{
	p->userData = userData;
}

void* mysql_parser_get_data(mysql_parser_tt* p)
{
	return p->userData;
}

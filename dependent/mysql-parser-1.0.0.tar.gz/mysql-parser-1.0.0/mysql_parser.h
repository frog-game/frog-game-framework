#ifndef def_mysql_parser_h
#define def_mysql_parser_h

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <float.h>

enum
{
	mysql_errno_ok,
    mysql_errno_parser_handshake,
    mysql_errno_parser_error,
    mysql_errno_parser_field_count,
    mysql_errno_parser_column_def,
    mysql_errno_parser_row,
    mysql_errno_parser_ok,
    mysql_errno_parser_eof,
};

enum
{
	mysql_column_type_decimal = 0,
	mysql_column_type_tiny,
	mysql_column_type_short,
	mysql_column_type_long,
	mysql_column_type_float,
	mysql_column_type_double,
	mysql_column_type_null,
	mysql_column_type_timestamp,
	mysql_column_type_longlong,
	mysql_column_type_int24,
	mysql_column_type_date,
	mysql_column_type_time,
	mysql_column_type_datetime,
	mysql_column_type_year,
	mysql_column_type_newdate,
	mysql_column_type_varchar,
	mysql_column_type_bit,
	mysql_column_type_timestamp2,
	mysql_column_type_datetime2,
	mysql_column_type_time2,
	mysql_column_type_typed_array = 244,
	mysql_column_type_json = 245,
	mysql_column_type_newdecimal = 246,
	mysql_column_type_enum = 247,
	mysql_column_type_set = 248,
	mysql_column_type_tiny_blob= 249,
	mysql_column_type_medium_blob = 250,
	mysql_column_type_long_blob = 251,
	mysql_column_type_blob = 252,
	mysql_column_type_var_string = 253,
	mysql_column_type_string = 254,
	mysql_column_type_geometry = 255
};

enum
{
	mysql_header_ok = 0,
	mysql_header_eof = 0xfe,
	mysql_header_error = 0xff
};

typedef enum
{
	mysql_parser_type_unknown,
	mysql_parser_type_handshake,
	mysql_parser_type_result
} mysql_parser_type_tt;

enum
{
	mysql_parser_state_end,
	mysql_parser_state_handshake,
	mysql_parser_state_ok,
	mysql_parser_state_error,
	mysql_parser_state_resultSet,
	mysql_parser_state_columnDef,
	mysql_parser_state_row,
};

#define MYSQL_ERRNO_OK					0
#define MYSQL_STATE_LENGTH				5
#define MYSQL_NUM_STR_LENGTH			20 
#define MYSQL_FLOAT_STR_LENGTH			FLT_DIG + 6 
#define MYSQL_DOUBLE_STR_LENGTH			DBL_DIG + 7 

#define MYSQL_PARSER_STATE(p)           ((p)->state)
#define MYSQL_PARSER_ERRNO(p)   		((p)->parserErrno)
typedef struct mysql_parser_s mysql_parser_tt;

typedef int32_t (*mysql_handshake_cb) (mysql_parser_tt*, uint8_t /*protocolVersion*/,const char* /*serverVersion*/,
	uint32_t /*threadId*/,const char* /*scramble*/,uint32_t /*serverCapabilities*/,uint8_t /*serverLang*/,uint16_t /*serverStatus*/);

typedef int32_t (*mysql_cb) (mysql_parser_tt*);

typedef int32_t (*mysql_ok_cb) (mysql_parser_tt*,uint64_t /*affectedRows*/,uint64_t /*insertId*/, uint16_t /*serverStatus*/,
	uint16_t /*warningCount*/,const char* /*message*/,size_t /*messageLength*/);

typedef int32_t (*mysql_error_cb) (mysql_parser_tt*,uint16_t /*errnoCode*/,size_t /*errorMsgLength*/,const char* /*errorMsg*/, const char* /*state*/);

typedef int32_t (*mysql_field_count_cb) (mysql_parser_tt*,uint32_t /*fieldCount*/);

typedef int32_t (*mysql_column_def_cb) (mysql_parser_tt*,uint32_t /*index*/,size_t /*catalogLength*/,const char* /*catalog*/,
	size_t /*DBLength*/,const char* /*DB*/,size_t /*tableLength*/,const char* /*table*/,size_t /*orgTableLength*/,
	const char* /*orgTable*/,size_t /*nameLength*/,const char* /*name*/,size_t /*orgNameLength*/,const char* /*orgName*/,
	uint32_t /*fieldLength*/,uint16_t /*fieldCharsetnr*/,uint16_t /*fieldFlag*/,uint8_t /*type*/,uint8_t /*decimals*/);

typedef int32_t (*mysql_row_cb) (mysql_parser_tt*,const char* /*buf*/, size_t /*length*/,size_t* valueOffset,size_t* valueLength);

typedef struct mysql_parser_settings_s
{
	mysql_cb      			on_complete;
	mysql_handshake_cb      on_handshake;
	mysql_ok_cb				on_ok;
	mysql_error_cb			on_error;
	mysql_field_count_cb    on_field_count;
	mysql_column_def_cb		on_column_def;
	mysql_row_cb			on_row;
} mysql_parser_settings_tt;

struct mysql_parser_s
{
	void* 		userData;
	uint32_t 	fieldCount;
	uint32_t    fieldIndex;
	uint8_t		type;
	uint8_t		state;
    uint8_t     parserErrno;
};

void mysql_parser_init(mysql_parser_tt* p,mysql_parser_type_tt type,void* userData);

void mysql_parser_reset(mysql_parser_tt* p,mysql_parser_type_tt type);

size_t mysql_parser_execute(mysql_parser_tt *p, const mysql_parser_settings_tt* settings, const char* buf, size_t len);

mysql_parser_type_tt mysql_parser_get_type(mysql_parser_tt* p);

void mysql_parser_set_data(mysql_parser_tt* p, void* userData);

void* mysql_parser_get_data(mysql_parser_tt* p);

#endif